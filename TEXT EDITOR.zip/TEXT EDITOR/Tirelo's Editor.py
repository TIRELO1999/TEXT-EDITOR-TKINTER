# THIS TEXT EDITOR WAS DEVELOPED BY 'TIRELO GLIFFORD LESUFI'
# YOU ARE NOT ALLOWED TO PUBLISH THIS TEXT EDITOR AS YOUR OWN UNLESS GIVEN PERMISSION FROM
# TIRELO GLIFFORD LESUFI

from tkinter import *
from tkinter.messagebox import *
import  tkinter.filedialog as fd
import  os


file_name = None

root=Tk()
root.title("Tirelo's Editor")
root.geometry("800x400")

file=None
theme_choice=StringVar()

show_line_number = IntVar()
show_line_number.set(1)
show_cursor_info=BooleanVar()



menu_bar=Menu(root)
file_menu = Menu(menu_bar, tearoff=0)
edit_menu=Menu(menu_bar,tearoff=0)
view_menu=Menu(menu_bar,tearoff=0)
about_menu=Menu(menu_bar,tearoff=0)
themes_menu=Menu(view_menu,tearoff=0)




# all file menu-items will be added here next

#main menu
menu_bar.add_cascade(label='File', menu=file_menu)
menu_bar.add_cascade(label='Edit', menu=edit_menu)
menu_bar.add_cascade(label='View', menu=view_menu)
menu_bar.add_cascade(label='About', menu=about_menu)
root.config(menu=menu_bar)

#file menu
file_menu.add_command(label="New ",activebackground="green",command=lambda :newFile())
file_menu.add_command(label="Open",activebackground="green",command=lambda :open_file())
file_menu.add_command(label="Save",activebackground="green",command=lambda :save())
file_menu.add_command(label="Save as",activebackground="green",command=lambda :save_as())
file_menu.add_separator()
file_menu.add_command(label="Exit",activebackground="red",command=lambda :quitApp())

#edit menu

#edit_menu.add_command(label="Select All      (CTRL+A)",activebackground="green",command=lambda :selectAll())
edit_menu.add_command(label="Cut               (CTRL+X)",activebackground="green",command=lambda :cut())
edit_menu.add_command(label="Copy            (CTRL+C)" ,activebackground="green",command=lambda :copy())
edit_menu.add_command(label="Paste            (CTRL+V)" ,activebackground="green",command=lambda :paste())
edit_menu.add_separator()
edit_menu.add_command(label="Select All      (CTRL+A)",activebackground="green",command=lambda :selectAll())
#                                                                                                                       073 155 5836
#view menu
view_menu.add_checkbutton(label="Show Line Number",activebackground="green",variable=show_line_number)
view_menu.add_checkbutton(label='Show Cursor Location at Bottom',activebackground="green",variable=show_cursor_info, command=lambda :show_cursor_info_bar())

# == view's menus

view_menu.add_cascade(label="Themes",activebackground="green", menu=themes_menu)
themes_menu.add_radiobutton(label="Default",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="Black and White",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="Night Vision",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="DayLight",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="Cobalt Blue",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="Olive Green",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="Orange Monkey",activebackground="green", variable=theme_choice,command=lambda :change_theme())
themes_menu.add_radiobutton(label="Red and White",activebackground="green", variable=theme_choice,command=lambda :change_theme())

#about menu
about_menu.add_command(label="About",activebackground="green", command=lambda :shotAbout())
about_menu.add_command(label="Help",activebackground="green")

# shortcut_bar = Frame(root, height=25, background='light sea green')
# shortcut_bar.pack(expand='no', fill='x')
line_number_bar = Text(root, width=4, padx=3, takefocus=0,border=0,background='powder blue', state='disabled', wrap='none')
line_number_bar.pack(side='left', fill='y')


#allowing text editing space
content_text = Text(root, wrap='word',width=30,height=5,undo=True)
content_text.pack(expand='yes', fill='both')
scroll_bar = Scrollbar(content_text)

content_text.configure(yscrollcommand=scroll_bar.set)
scroll_bar.config(command=content_text.yview)
scroll_bar.pack(side='right', fill='y')

cursor_info_bar = Label(content_text, text='Line: 1 | Column: 1')
cursor_info_bar.pack(expand=NO, fill=None, side=RIGHT,anchor='se')


def on_content_changed(number):
    update_line_numbers()
content_text.bind('<Any-KeyPress>', on_content_changed)

def get_line_numbers():
    output = ''
    if show_line_number.get():
        row, col = content_text.index("end").split('.')
        for i in range(1, int(row)):
            output += str(i)+ '\n'
    return output

def update_line_numbers():
    line_numbers = get_line_numbers()
    line_number_bar.config(state=NORMAL)
    line_number_bar.delete('1.0', END)
    line_number_bar.insert('1.0', line_numbers)
    line_number_bar.config(state=DISABLED)

def on_content_changed():
    update_line_numbers()
    update_cursor_info_bar()

def show_cursor_info_bar():
    show_cursor_info_checked = show_cursor_info.get()
    if show_cursor_info_checked:
        cursor_info_bar.pack(expand='no', fill=None, side='right',anchor='se')
    else:
        cursor_info_bar.pack_forget()

def update_cursor_info_bar():
    row, col = content_text.index(INSERT).split('.')
    line_num, col_num = str(int(row)), str(int(col)+1) # col starts at 0
    infotext = "Line: {0} | Column: {1}".format(line_num, col_num)
    cursor_info_bar.config(text=infotext)


def quitApp():
    root.destroy()
def shotAbout():
    showinfo("Tirelo's Editor","This is Text  is developed by Tirelo Clifford Lesufi ")

def newFile():
    root.title("Untitled - Tirelo's Editor")
    file=None
    content_text.delete(1.0,END)


def cut():
    content_text.event_generate("<<Cut>>")
def copy():
    content_text.event_generate("<<Copy>>")
def paste():
    content_text.event_generate("<<Paste>>")
def selectAll():
    content_text.event_generate("<<SelectAll>>")

def open_file():
    input_file_name =fd.askopenfilename(defaultextension=".txt",filetypes=[("All Files", "*.*"), ("Text Documents","*.txt")])
    if input_file_name:
        global file_name
        file_name = input_file_name
        root.title('{} - {}'.format(os.path.basename(file_name),
                                "Tirelo's Editor"))
        content_text.delete(1.0, END)
        with open(file_name) as _file:
            content_text.insert(1.0, _file.read())

#__________________________________________________________________________________________________________________________________
#____________________________________________save and save as methods______________________________________________________________
#__________________________________________________________________________________________________________________________________
def save():
    global file_name
    if not file_name:
        save_as()
    else:
        write_to_file(file_name)
    return "break"
def save_as():
    input_file_name = fd.asksaveasfilename(defaultextension=".txt", filetypes=[("All Files", "*.*"),("Text Documents", "*.txt")])
    if input_file_name:
        global file_name
        file_name = input_file_name
        write_to_file(file_name)
        root.title('{} - {}'.format(os.path.basename(file_name),"Tirelo's Editor"))
    return "break"
def write_to_file(file_name):
    try:
        content = content_text.get(1.0, 'end')
        with open(file_name, 'w') as the_file:
            the_file.write(content)
    except IOError:pass
# pass for now but we show some warning - we do this in next iteration

# content_text.bind('<Control-N>', new_file)
# content_text.bind('<Control-n>', new_file)
content_text.bind('<Control-O>', open_file)
content_text.bind('<Control-o>', open_file)
content_text.bind('<Control-S>', save)
content_text.bind('<Control-s>', save)


color_schemes = {'Default': '#000000.#FFFFFF',
                 'Black and White':'#FFFFFF.#000000',
                 'Night Vision': 'black.#D1E7E0',
                 'DayLight': 'black.yellow',
                 'Cobalt Blue':'#ffffBB.#3333aa',
                 'Olive Green': '#D1E7E0.#5B8340',
                 'Night Mode':'black.white' ,
                 'Orange Monkey':'black.orange',
                 'Red and White':'white.red',}

def change_theme():
    selected_theme = theme_choice.get()
    fg_bg_colors = color_schemes.get(selected_theme)
    foreground_color, background_color = fg_bg_colors.split('.')
    content_text.config(background=background_color,fg=foreground_color)


popup_menu = Menu(content_text)
for i in ('cut', 'copy', 'paste'):
    cmd = eval(i)
    popup_menu.add_command(label=i, compound='left', command=cmd)
    popup_menu.add_separator()
    popup_menu.add_command(label='Select All', underline=7,command=selectAll())
def show_popup_menu(event):
    popup_menu.tk_popup(event.x_root, event.y_root)
content_text.bind('<Button-3>', show_popup_menu)

root.mainloop()